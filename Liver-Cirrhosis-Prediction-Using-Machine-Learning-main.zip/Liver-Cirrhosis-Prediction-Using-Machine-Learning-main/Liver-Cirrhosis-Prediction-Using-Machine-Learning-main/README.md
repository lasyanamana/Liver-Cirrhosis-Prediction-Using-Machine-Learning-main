# Liver-Cirrhosis-Prediction-Using-Machine-Learning
Predicting liver cirrhosis risk using machine learning to enable early detection and preventive measures.
